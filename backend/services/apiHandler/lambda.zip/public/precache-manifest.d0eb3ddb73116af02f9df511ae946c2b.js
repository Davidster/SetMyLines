self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "0bc3e06b1bf44bb49a03",
    "url": "/static/js/main.2eb9961a.chunk.js"
  },
  {
    "revision": "282428c89670183acebd",
    "url": "/static/js/2.9d971ad6.chunk.js"
  },
  {
    "revision": "0bc3e06b1bf44bb49a03",
    "url": "/static/css/main.da12b750.chunk.css"
  },
  {
    "revision": "f18cd543bc5ba4db0d97c1f80b4ce77d",
    "url": "/index.html"
  }
];